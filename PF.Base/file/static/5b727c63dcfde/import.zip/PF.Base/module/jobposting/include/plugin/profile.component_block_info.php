<?php 
$_SESSION['aUserJobPosting'] = $aUser;

?>