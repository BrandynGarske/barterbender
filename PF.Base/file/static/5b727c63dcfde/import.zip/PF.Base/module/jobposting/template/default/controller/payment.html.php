<div class="ynj_box_payment">
	<h3>{phrase var='payment_methods'}</h3>
	{module name='api.gateway.form'}			
</div>