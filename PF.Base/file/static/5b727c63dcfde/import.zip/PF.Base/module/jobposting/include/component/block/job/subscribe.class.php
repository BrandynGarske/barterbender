<?php

defined('PHPFOX') or exit('NO DICE!');

class jobposting_component_block_job_subscribe extends Phpfox_component{

	public function process ()
	{
		
		return 'block';
	}
}