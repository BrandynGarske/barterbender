<div class="block ynjp_subscribeJob">
	<a href="#" class="btn btn-lg btn-primary" onclick="$Core.box('jobposting.subscribe',560,''); return false;"> {phrase var='subscribe_job'} </a>
</div>