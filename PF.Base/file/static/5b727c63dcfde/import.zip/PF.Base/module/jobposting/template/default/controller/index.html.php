{if $iPage <= 1}{module name='jobposting.job.search'}{/if}
{if ($bInHomepage && !Phpfox::isMobile()) }
    {module name='jobposting.job.featured-slideshow'}
{/if}

{if !count($aJobs) && $iPage <= 1}
	<div>{phrase var='no_jobs_found'}</div>
{else}
{foreach from=$aJobs item=aJob}
	{template file='jobposting.block.job.entry'}
{/foreach}

{if !Phpfox::isMobile() && (Phpfox::getUserParam('jobposting.can_approve_job') || Phpfox::getUserParam('jobposting.can_delete_job_other_user'))}
{moderation}
{/if}
{pager}
{/if}
