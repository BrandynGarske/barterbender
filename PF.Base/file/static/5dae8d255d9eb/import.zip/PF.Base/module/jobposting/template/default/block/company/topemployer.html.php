{foreach from=$aBlockCompanies item=item}
	{template file="jobposting.block.company.block_entry"}
{/foreach}
