{foreach from=$aBlockJobs item=item}
	{template file="jobposting.block.job.block_entry"}
{/foreach}
