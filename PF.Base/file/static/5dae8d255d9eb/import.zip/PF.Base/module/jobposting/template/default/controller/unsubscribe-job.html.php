<?php
defined('PHPFOX') or exit('NO DICE!');
?>

<div class="{if $isValid}alert alert-success{else}error_message{/if}">
    {$message}
</div>
