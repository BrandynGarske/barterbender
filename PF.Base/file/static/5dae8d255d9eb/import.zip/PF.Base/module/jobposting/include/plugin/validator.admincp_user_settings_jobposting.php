<?php
$aValidation = [
    'numbers_of_company' => [
        'def' => 'int',
        'min' => '0',
        'title' => _p('"How many companies can user own?" must be greater than or equal to 0'),
    ],
];